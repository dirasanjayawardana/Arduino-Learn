if you use AVR code and software which apply by us,please read it .it can help you understand our product.

Please open 2609-1.jpg and 2609-2.jpg ,in 2609-2.jpg:
you can operate by following steps:

1->2->3->4->5->6->7->8

then copy 32bytes to you code.