var searchData=
[
  ['dd',['dd',['../class_m_d___d_s1307.html#ab06a83fe6b531936a63663ff4638be0d',1,'MD_DS1307']]],
  ['dow',['dow',['../class_m_d___d_s1307.html#a627a67e62dc862ea7ed8915621980783',1,'MD_DS1307']]]
];
