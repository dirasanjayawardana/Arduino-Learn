var searchData=
[
  ['calcdow',['calcDoW',['../class_m_d___d_s1307.html#a3ede82a093f3721371304fd806ff0cae',1,'MD_DS1307']]],
  ['control',['control',['../class_m_d___d_s1307.html#a094cf2b307045357c50b4d64a92420c7',1,'MD_DS1307']]]
];
