var class_m_d___d_s1307 =
[
    [ "MD_DS1307", "class_m_d___d_s1307.html#a385d43616f4ea92356852e5a83fb5b3e", null ],
    [ "MD_DS1307", "class_m_d___d_s1307.html#a77e0cbcd07064a756dbf562de3217f6c", null ],
    [ "calcDoW", "class_m_d___d_s1307.html#a3ede82a093f3721371304fd806ff0cae", null ],
    [ "control", "class_m_d___d_s1307.html#a094cf2b307045357c50b4d64a92420c7", null ],
    [ "isRunning", "class_m_d___d_s1307.html#a05cff9941dcbbab0952cff4545570a35", null ],
    [ "now", "class_m_d___d_s1307.html#a4b1f9684f4117a62f321e44b43fcf2a0", null ],
    [ "readRAM", "class_m_d___d_s1307.html#ad7535e324d52b2c4fee2810b0d556b8f", null ],
    [ "readTime", "class_m_d___d_s1307.html#a13950bdfabeb406a1c53045406042126", null ],
    [ "status", "class_m_d___d_s1307.html#ab0ee54a31fcb1b0c81d5d8f37b8de597", null ],
    [ "writeRAM", "class_m_d___d_s1307.html#a9dcefcf779301467203d5faef1ff8d11", null ],
    [ "writeTime", "class_m_d___d_s1307.html#ad58f158fc2685e09d9ee5b6dd1dc1e29", null ],
    [ "dd", "class_m_d___d_s1307.html#ab06a83fe6b531936a63663ff4638be0d", null ],
    [ "dow", "class_m_d___d_s1307.html#a627a67e62dc862ea7ed8915621980783", null ],
    [ "h", "class_m_d___d_s1307.html#aa12449bb9deeb1c028a78b8d88fcd9d6", null ],
    [ "m", "class_m_d___d_s1307.html#adc2fc7eda056879055a21ea5e330b8cf", null ],
    [ "mm", "class_m_d___d_s1307.html#afdabb79ca86dcdda1fa3c0a9499a6c02", null ],
    [ "pm", "class_m_d___d_s1307.html#abd3a8fed17d7e29e739f6149cd28227d", null ],
    [ "s", "class_m_d___d_s1307.html#afe062c069ffe7b41dad3bbe730785f21", null ],
    [ "yyyy", "class_m_d___d_s1307.html#a8fb693d4e11be837647d57a455e56335", null ]
];